# Assignment III

## Running the program

To run the program, execute the following command:

```bash
make run
```

*It is recommended to compile the project before running it.

## Cleaning the project

To clean the project, execute the following command:

```bash
make clean
```

## Compiling the project

To compile the project, execute the following command:

```bash
make compile
```
